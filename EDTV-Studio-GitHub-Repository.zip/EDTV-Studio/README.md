# EDTV Studio

Creative production workspace untuk:
- Project
- Event: Photoshoot / Short Movie
- Script ala Celtx
- Action / Dialog / Expression / Shot
- Moodboard: Environment / Talent / POV Talent / Arah Cahaya
- Walkthrough Video
- Tombol Ganti Foto setelah upload

## Repository structure

```text
EDTV-Studio/
├── app/
│   ├── projects/
│   │   └── [id]/
│   │       └── page.tsx
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   └── Workspace.tsx
├── lib/
│   └── supabase/
│       ├── client.ts
│       ├── server.ts
│       └── storage.ts
├── supabase/
│   └── schema.sql
├── .env.example
├── .gitignore
├── package.json
├── tsconfig.json
└── README.md
```

## Run local

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000`.

## Supabase

1. Buat project Supabase.
2. Buka SQL Editor.
3. Jalankan `supabase/schema.sql`.
4. Isi `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

## GitHub

```bash
git init
git add .
git commit -m "Initial EDTV Studio"
git branch -M main
git remote add origin https://github.com/USERNAME/EDTV-Studio.git
git push -u origin main
```

## Vercel

Import repository GitHub ini ke Vercel, lalu tambahkan environment variables:

- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_ANON_KEY`

Lalu Deploy.

> Catatan: UI upload pada starter ini sudah punya preview lokal. Integrasi CRUD Supabase dan upload Storage penuh bisa dilanjutkan sebagai tahap berikutnya tanpa mengubah struktur repository.
