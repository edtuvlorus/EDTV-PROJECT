"use client";

import { useRef, useState } from "react";
import { Clapperboard, FileText, Image as ImageIcon, PlaySquare, Upload, Replace } from "lucide-react";

type BlockType = "action" | "dialog" | "expression" | "shot";
type Block = { id:number; type:BlockType; text:string; meta?:string };
type Mood = { key:string; title:string; file?:string };

const initialBlocks: Block[] = [
  {id:1,type:"action",text:"Talent berjalan memasuki frame dari arah kanan lalu berhenti di titik mark."},
  {id:2,type:"dialog",text:"Oke, kita mulai dari sini.",meta:"TALENT"},
  {id:3,type:"expression",text:"Tenang, percaya diri, natural."},
  {id:4,type:"shot",text:"Medium shot → slow push in, 35mm. Kamera sejajar mata."}
];

const moodDefaults: Mood[] = [
  {key:"environment",title:"FOTO ENVIRONMENT"},
  {key:"talent",title:"FOTO KETIKA ADA TALENT"},
  {key:"pov",title:"FOTO DARI SUDUT PANDANG TALENT"},
  {key:"light",title:"FOTO ARAH CAHAYA"}
];

export default function Workspace({projectId}:{projectId:string}) {
  const [tab,setTab]=useState("script");
  const [blocks,setBlocks]=useState(initialBlocks);
  const [moods,setMoods]=useState(moodDefaults);
  const [video,setVideo]=useState<string>();
  const inputs=useRef<Record<string,HTMLInputElement|null>>({});

  function add(type:BlockType){
    setBlocks(v=>[...v,{id:Date.now(),type,text:"Tulis isi di sini..."}]);
  }
  function pick(key:string){
    inputs.current[key]?.click();
  }
  function onImage(key:string,file?:File){
    if(!file) return;
    setMoods(v=>v.map(m=>m.key===key?{...m,file:URL.createObjectURL(file)}:m));
  }
  return (
    <div className="edtv">
      <aside className="sidebar">
        <div className="brand"><span className="logo"><Clapperboard size={18}/></span>EDTV</div>
        <div className="nav">
          <button onClick={()=>setTab("overview")}>Overview</button>
          <button className={tab==="script"?"active":""} onClick={()=>setTab("script")}><FileText size={15}/> Script</button>
          <button className={tab==="moodboard"?"active":""} onClick={()=>setTab("moodboard")}><ImageIcon size={15}/> Moodboard</button>
          <button className={tab==="walkthrough"?"active":""} onClick={()=>setTab("walkthrough")}><PlaySquare size={15}/> Walkthrough</button>
        </div>
        <div className="project-mini">
          <small>PROJECT</small>
          <div style={{fontWeight:700,marginTop:6}}>Untitled Project</div>
          <div style={{fontSize:12,color:"#737987",marginTop:3}}>ID: {projectId}</div>
        </div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div><div className="eyebrow">Photoshoot / Short Movie</div><h1>Untitled Project</h1></div>
          <button className="btn primary">Save Project</button>
        </div>

        {tab==="script" && <section className="card">
          <div className="topbar" style={{marginBottom:18}}>
            <div><h2>Script</h2><p>Format kerja ala Celtx untuk kebutuhan produksi.</p></div>
            <div className="row">
              <button className="btn" onClick={()=>add("action")}>+ Action</button>
              <button className="btn" onClick={()=>add("dialog")}>+ Dialog</button>
              <button className="btn" onClick={()=>add("expression")}>+ Expression</button>
              <button className="btn" onClick={()=>add("shot")}>+ Shot</button>
            </div>
          </div>
          <div className="script">
            {blocks.map(b=><div className="block" key={b.id}>
              <div className="block-label">{b.type}{b.meta?` · ${b.meta}`:""}</div>
              <textarea value={b.text} onChange={e=>setBlocks(v=>v.map(x=>x.id===b.id?{...x,text:e.target.value}:x))}/>
            </div>)}
          </div>
        </section>}

        {tab==="moodboard" && <section className="card">
          <div style={{marginBottom:18}}><h2>Moodboard</h2><p>Upload referensi visual. Setelah foto masuk, tombol akan berubah menjadi Ganti Foto.</p></div>
          <div className="moods">
            {moods.map(m=><div className="mood" key={m.key}>
              <div className="mood-head"><span className="mood-title">{m.title}</span><ImageIcon size={16}/></div>
              <div className="preview">{m.file?<img src={m.file}/>:<span>Belum ada foto</span>}</div>
              <input ref={el=>{inputs.current[m.key]=el}} hidden type="file" accept="image/*" onChange={e=>onImage(m.key,e.target.files?.[0])}/>
              <button className="btn ghost upload" onClick={()=>pick(m.key)}>
                {m.file?<><Replace size={15}/> Ganti Foto</>:<><Upload size={15}/> Upload Foto</>}
              </button>
            </div>)}
          </div>
        </section>}

        {tab==="walkthrough" && <section className="card">
          <h2>Walkthrough Video</h2><p>Upload video walkthrough lokasi produksi.</p>
          <div className="video">
            {video ? <video src={video} controls style={{width:"100%",maxHeight:420,borderRadius:12}}/> : <><PlaySquare size={28}/><div style={{margin:"10px 0"}}>Belum ada walkthrough</div></>}
            <input hidden type="file" accept="video/*" id="walkthrough"/>
            <label htmlFor="walkthrough" className="btn primary" style={{display:"inline-flex",gap:7,alignItems:"center"}}>
              <Upload size={15}/> Upload Video
            </label>
          </div>
        </section>}

        {tab==="overview" && <section className="grid">
          <div className="card"><div className="eyebrow">EVENT</div><h2>Photoshoot / Short Movie</h2><p>Workspace produksi untuk script dan visual reference.</p></div>
          <div className="card"><div className="eyebrow">STATUS</div><h2>Draft</h2><p>Project siap dikembangkan dan dihubungkan ke Supabase.</p></div>
        </section>}
      </main>
    </div>
  );
}