export const STORAGE_BUCKET = "edtv-assets";

export function buildStoragePath(userId:string, projectId:string, category:string, filename:string) {
  const safe = filename.replace(/[^a-zA-Z0-9._-]/g, "-");
  return `${userId}/${projectId}/${category}/${crypto.randomUUID()}-${safe}`;
}