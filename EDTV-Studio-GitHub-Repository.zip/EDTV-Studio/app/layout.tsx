import "./globals.css";

export const metadata = {
  title: "EDTV Studio",
  description: "Creative production workspace for scripts, moodboards and walkthroughs."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}