import { ArrowRight, Clapperboard, FileText, Image as ImageIcon, PlaySquare } from "lucide-react";
import Link from "next/link";

const modules = [
  { title: "Script", desc: "Tulis script dengan blok Action, Dialog, Expression, dan Shot.", icon: FileText, href: "/projects/demo" },
  { title: "Moodboard", desc: "Kumpulkan referensi environment, talent, POV, dan lighting.", icon: ImageIcon, href: "/projects/demo" },
  { title: "Walkthrough", desc: "Simpan video walkthrough lokasi untuk kebutuhan produksi.", icon: PlaySquare, href: "/projects/demo" }
];

export default function Home() {
  return (
    <div className="edtv">
      <aside className="sidebar">
        <div className="brand"><span className="logo"><Clapperboard size={18}/></span>EDTV</div>
        <div className="nav">
          <button className="active">Overview</button>
          <button>Projects</button>
          <button>Templates</button>
        </div>
        <div className="project-mini">
          <small>PROJECT AKTIF</small>
          <div style={{fontWeight:700,marginTop:6}}>Untitled Project</div>
          <div style={{fontSize:12,color:"#737987",marginTop:3}}>Photoshoot / Short Movie</div>
        </div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div>
            <div className="eyebrow">Creative production workspace</div>
            <h1>EDTV Studio</h1>
          </div>
          <button className="btn primary">+ New Project</button>
        </div>

        <div className="card" style={{marginBottom:18}}>
          <div className="eyebrow">PROJECT</div>
          <h2 style={{fontSize:23,margin:"7px 0 5px"}}>Untitled Project</h2>
          <p>Photoshoot / Short Movie</p>
          <Link href="/projects/demo" className="btn primary" style={{display:"inline-flex",alignItems:"center",gap:8,textDecoration:"none"}}>
            Open Workspace <ArrowRight size={15}/>
          </Link>
        </div>

        <div className="grid">
          {modules.map((m) => {
            const Icon=m.icon;
            return (
              <Link href={m.href} key={m.title} className="card" style={{textDecoration:"none",color:"inherit"}}>
                <Icon size={22} color="#6d5dfc"/>
                <h2 style={{marginTop:15}}>{m.title}</h2>
                <p>{m.desc}</p>
                <span style={{fontSize:13,fontWeight:700}}>Open workspace →</span>
              </Link>
            )
          })}
        </div>
      </main>
    </div>
  );
}